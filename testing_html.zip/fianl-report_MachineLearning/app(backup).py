import joblib
model_pretrained1 = joblib.load('House-Price-Final.pkl')
import numpy as np

from flask import Flask, request, render_template, redirect, url_for
app = Flask(__name__,static_folder='templates/static')

@app.route("/")
def formPage():
    return render_template('index.html')
 
@app.route("/submit", methods=['POST'])
def submit():

    
    if request.method == 'POST':

        form_data = request.form

        #inputing = [[int(form_data['LotFrontage']), int(form_data['LotArea']), int(form_data['OverallQual']), int(form_data['YearBuilt']), int(form_data['YearRemodAdd']), int(form_data['MasVnrArea']), int(form_data['TotalBsmtSF']), int(form_data['firstFlrSF']), int(form_data['secondFlrSF']), int(form_data['GrLivArea']), int(form_data['FullBath']), int(form_data['Fireplaces']), int(form_data['GarageArea']), 240, 0, 0]]
        inputs = [[int(form_data['LotFrontage']),int(form_data['LotArea']),int(form_data['OverallQual']),int(form_data['YearBuilt']),int(form_data['YearRemodAdd']),int(form_data['MasVnrArea']),int(form_data['TotalBsmtSF']),int(form_data['firstFlrSF']),int(form_data['secondFlrSF']),int(form_data['GrLivArea']),int(form_data['FullBath']),int(form_data['Fireplaces']),int(form_data['GarageArea']),int(form_data['WoodDeckSF']),int(form_data['OpenPorchSF']),int(form_data['PoolArea'])]]
        prediction = model_pretrained1.predict(inputs)
        return redirect(url_for('formPage', _anchor='result'))
        return render_template("index.html",LotFrontage = form_data['LotFrontage'], LotArea = form_data['LotArea'], OverallQual = form_data['OverallQual'],
                               YearBuilt = form_data['YearBuilt'], YearRemodAdd = form_data['YearRemodAdd'], MasVnrArea = form_data['MasVnrArea'], TotalBsmtSF = form_data['TotalBsmtSF'], firstFlrSF = form_data['firstFlrSF'],
                               secondFlrSF = form_data['secondFlrSF'],GrLivArea = form_data['GrLivArea'], FullBath = form_data['FullBath'], Fireplaces = form_data['Fireplaces'], 
                               GarageArea = form_data['GarageArea'], WoodDeckSF = form_data['WoodDeckSF'], OpenPorchSF = form_data['OpenPorchSF'], PoolArea = form_data['PoolArea'],
                               prediction = prediction[0])
    


    

    
    

 
if __name__ == "__main__":
    app.run()
